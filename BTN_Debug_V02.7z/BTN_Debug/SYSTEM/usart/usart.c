
#include "sys.h"
#include "usart.h"	  


uint8_t USART_TX_BUF[USART_TEC_LEN];  //���ͻ���,���USART_REC_LEN���ֽ�.
uint8_t USART_RX_BUF[USART_REC_LEN];  //���ջ���,���USART_REC_LEN���ֽ�.
uint8_t USART_RX_STA=0; //����״̬���	  

/**
  * @brief  
  * @param  uint32_t bound
  * @retval None
  */
void USART1_Init(uint32_t bound)
{
  	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA , ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	
  	GPIO_Init(GPIOA, &GPIO_InitStructure); 
	
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  	GPIO_Init(GPIOA, &GPIO_InitStructure);
   
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  	GPIO_Init(GPIOA, &GPIO_InitStructure);

  	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1 ;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;		
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			
	NVIC_Init(&NVIC_InitStructure);	

    USART_InitStructure.USART_BaudRate = bound;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	

  	USART_Init(USART1, &USART_InitStructure);
  	USART_ITConfig(USART1, USART_IT_RXNE, DISABLE);
  	USART_Cmd(USART1, ENABLE);             
}

/**
  * @brief  
  * @param  None
  * @retval None
  */
void USART1_IRQHandler(void)                
{
	uint8_t res = 0;

	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) //�����ж�
	{
		res = USART_ReceiveData(USART1); 
    } 
}


void USART1_SendDate(char *buf,...)
{
	u16 i,j; 
	va_list ap; 	
	va_start(ap,buf);
	vsprintf((char*)USART_TX_BUF,buf,ap);
	va_end(ap);
	i=strlen((const char*)USART_TX_BUF);	
	for(j=0;j<i;j++)						
	{
		while(USART_GetFlagStatus(USART1,USART_FLAG_TC)==RESET); 
		USART_SendData(USART1,USART_TX_BUF[j]); 
	}
}

void USART1_SendDateHex(const char *buf)
{
	uint8_t i;

	for(i = 0;i < 4;i++)
	{
		while(USART_GetFlagStatus(USART1,USART_FLAG_TC)==RESET); 
		USART_SendData(USART1,buf[i]);
	}
		
}


