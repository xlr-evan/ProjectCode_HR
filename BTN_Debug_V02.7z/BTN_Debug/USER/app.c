
#include "app.h"
#include "cmd.h"


/**
  * @brief  MCU init
  * @param  None
  * @retval None
  */
void SYS_Init(void)
{
	NVIC_Configuration();
	delay_init();
	USART1_Init(9600);
	
	TIM2_init();
	LED_Init();
    BTN_Init();
	Key_Init();
	Run = 0;
	delay_ms(200);
	Run = 1;
	delay_ms(200);
	Run = 0;
	delay_ms(200);
	Run = 1;
	delay_ms(200);
	Run = 0;
	delay_ms(200);
	Run = 1;

    /* 检测按键是否有损坏 */
    while(KEY_Scan(IN))
    {
        LED2 = ~LED2;
        delay_ms(100);
    }
    
    while(KEY_Scan(OUT))
    {
        LED9 = ~LED9;
        delay_ms(100);
    }
    
    IWDG_Init(6,950);
}

/**
  * @brief  BTN Task poll
  * @param  None
  * @retval None
  */
int BTN_Poll(void)
{ 
	for(;;){
		
		/* task1: BTN Scan */	
		if(task_100ms == 1)
		{
			task_100ms = 0;

			/* inside btn board */
			INBTN_Logic();
            
			/* outside btn board */
			OUTBTN_Logic();
		}
		
		/* Task3: SYS LED */
		if(task_1s == 1)
		{
			task_1s = 0;
            
			Run = ~Run;
			IWDG_Feed();
		}
	}
}

/**
  * @brief  Outside btn logic control
  * @param  None
  * @retval None
  */
void OUTBTN_Logic(void)
{
	static uint8_t xEVENT = EV_MLOCK_ON; //
	static uint16_t cntTime = 0;
	static uint8_t bedupdownSTA = EV_BEDLOCK_OFF;
	static uint8_t backSTA = EV_BACKLOCK_OFF;
	static uint8_t legSTA = EV_LEGLOCK_OFF;
	static uint8_t pitchSTA = EV_PITCHLOCK_OFF;
	static uint8_t rollSTA = EV_ROLLLOCK_OFF;
	static uint8_t bedLock = 0,backLock = 0,legLock = 0,pitchLock = 0,rollLock = 0;
	
	switch(xEVENT)
	{
		case EV_MLOCK_ON:
				cntTime = 0;
				LED9 = 0;
				if(MLOCK_Scan(OUT) == 0x1) 
				{
					xEVENT = EV_MLOCK_OFF;
					LED9 = 1;
					Run = 0;
					while(MLOCK_Scan(OUT));
				}
				break;
		case EV_MLOCK_OFF:
				cntTime++;
				switch(KEY_Scan(OUT))
				{
					case 0x15:
								cntTime = 0;
								if(!bedLock)
								{
									RS485_RDTX_EN;
									delay_ms(5);
									USART1_SendDateHex(OUTBED_UP_ON);
									while(KEY_Scan(OUT));
									USART1_SendDateHex(OUTBED_UP_OFF);
									delay_ms(5);
									RS485_RDRX_EN;
								}
								break;
					case 0x14:
								cntTime = 0;			
								if(!backLock) 
								{
									RS485_RDTX_EN;
									delay_ms(5);
									USART1_SendDateHex(OUTBACK_UP_ON);
									while(KEY_Scan(OUT));
									USART1_SendDateHex(OUTBACK_UP_OFF);
									delay_ms(5);
									RS485_RDRX_EN;
								}
								break;							
					case 0x13:
								cntTime = 0;
								if(!legLock)
								{
									RS485_RDTX_EN;
									delay_ms(5);
									USART1_SendDateHex(OUTLEG_UP_ON);
									while(KEY_Scan(OUT));
									USART1_SendDateHex( OUTLEG_UP_OFF);
									delay_ms(5);
									RS485_RDRX_EN;
								}
								break;
					case 0x12:
								cntTime = 0;
								if(!pitchLock)
								{
									RS485_RDTX_EN;
									delay_ms(5);
									USART1_SendDateHex(OUTPITCH_AFTER_ON);
									while(KEY_Scan(OUT));
									USART1_SendDateHex(OUTPITCH_AFTER_OFF);
									delay_ms(5);
									RS485_RDRX_EN;
								}
								break;
					case 0x11:
								cntTime = 0;
								if(!rollLock)
								{

									RS485_RDTX_EN;
									delay_ms(5);
									USART1_SendDateHex(OUTROLL_LEFT_ON);
									while(KEY_Scan(OUT));
									USART1_SendDateHex(OUTROLL_LEFT_OFF);
									delay_ms(5);
									RS485_RDRX_EN;
								}
								break;
					case 0x20:
								cntTime = 0;
								switch(bedupdownSTA)
								{
									case EV_BEDLOCK_OFF:
														LED4 = 0;
														bedLock = 1;
														bedupdownSTA = EV_BEDLOCK_ON;
														break;
									case EV_BEDLOCK_ON:
														LED4 = 1;
														bedLock = 0;
														bedupdownSTA = EV_BEDLOCK_OFF;
														break;
								} 
								while(KEY_Scan(OUT));
								break;					
					case 0x19:
								cntTime = 0;
								switch(backSTA)
								{
									case EV_BACKLOCK_OFF:
														LED5 = 0;
														backLock = 1;
														backSTA = EV_BACKLOCK_ON;
														break;
									case EV_BACKLOCK_ON:
														LED5 = 1;
														backLock = 0;
														backSTA = EV_BACKLOCK_OFF;
														break;
								} 
								while(KEY_Scan(OUT));
								break;
					case 0x18:
								cntTime = 0;
								switch(legSTA)
								{
									case EV_LEGLOCK_OFF:
														LED6 = 0;
														legLock = 1;
														legSTA = EV_LEGLOCK_ON;
														break;
									case EV_LEGLOCK_ON:
														LED6 = 1;
														legLock = 0;
														legSTA = EV_LEGLOCK_OFF;
														break;
								} 
								while(KEY_Scan(OUT));
								break;
					case 0x17:
								cntTime = 0;
								switch(pitchSTA)
								{
									case EV_PITCHLOCK_OFF:
														LED7 = 0;
														pitchLock = 1;
														pitchSTA = EV_PITCHLOCK_ON;
														break;
									case EV_PITCHLOCK_ON:
														LED7 = 1;
														pitchLock = 0;
														pitchSTA = EV_PITCHLOCK_OFF;
														break;
								} 
								while(KEY_Scan(OUT));
								break;
					case 0x16:
								cntTime = 0;
								switch(rollSTA)
								{
									case EV_ROLLLOCK_OFF:
														LED8 = 0;
														rollLock = 1;
														rollSTA = EV_ROLLLOCK_ON;
														break;
									case EV_ROLLLOCK_ON:
														LED8 = 1;
														rollLock = 0;
														rollSTA = EV_ROLLLOCK_OFF;
														break;
								} 
								while(KEY_Scan(OUT));
								break;
					case 0x28:
								cntTime = 0;		
								if(!bedLock) 
								{
									RS485_RDTX_EN;
									delay_ms(5);
									USART1_SendDateHex(OUTBED_DOWN_ON);
									while(KEY_Scan(OUT));
									USART1_SendDateHex(OUTBED_DOWN_OFF);
									delay_ms(5);
									RS485_RDRX_EN;
								}
								break;
					case 0x27:
								cntTime = 0;
								if(!backLock) 
								{
									RS485_RDTX_EN;
									delay_ms(5);
									USART1_SendDateHex(OUTBACK_DOWN_ON);
									while(KEY_Scan(OUT));
									USART1_SendDateHex(OUTBACK_DOWN_OFF);
									delay_ms(5);
									RS485_RDRX_EN;
								}
								break;		
					case 0x26:
								cntTime = 0;
								if(!legLock)
								{
									RS485_RDTX_EN;
									USART1_SendDateHex(OUTLEG_DOWN_ON);
									while(KEY_Scan(OUT));
									USART1_SendDateHex(OUTLEG_DOWN_OFF);
									RS485_RDRX_EN;
								}
								break;						
					case 0x25:
								cntTime = 0;
								if(!pitchLock) 
								{
									RS485_RDTX_EN;
									USART1_SendDateHex(OUTPITCH_FRONT_ON);
									while(KEY_Scan(OUT));
									USART1_SendDateHex(OUTPITCH_FRONT_OFF);
									RS485_RDRX_EN;
								}
								break;
					case 0x24:
								cntTime = 0;
								if(!rollLock) 
								{
									RS485_RDTX_EN;
									USART1_SendDateHex(OUTROLL_RIGHT_ON);
									while(KEY_Scan(OUT));
									USART1_SendDateHex(OUTROLL_RIGHT_OFF);
									RS485_RDRX_EN;
								}								
								break;
					case 0x21:
								cntTime = 0;
								RS485_RDTX_EN;
								USART1_SendDateHex(OUT_CALL_ON);
								while(KEY_Scan(OUT));
								USART1_SendDateHex(OUT_CALL_OFF);
								RS485_RDRX_EN;
								break;								
					case 0x09:	
								cntTime = 0;
								RS485_RDTX_EN;
								USART1_SendDateHex(OUT_FLOWER_ON);
								while(KEY_Scan(OUT));
								USART1_SendDateHex(OUT_FLOWER_OFF);
								RS485_RDRX_EN;
								break;	
					case 0x10:
								cntTime = 0;
								RS485_RDTX_EN;
								USART1_SendDateHex(OUT_CCP_ON);
								while(KEY_Scan(OUT));	
								USART1_SendDateHex(OUT_CCP_OFF);
								RS485_RDRX_EN;
								break;	
					case 0x22:
								cntTime = 0;
								RS485_RDTX_EN;
								USART1_SendDateHex(OUT_CPR_ON);
								while(KEY_Scan(OUT));
								USART1_SendDateHex(OUT_CPR_OFF);
								RS485_RDRX_EN;
								break;	
					case 0x23:
								cntTime = 0;
								LED9 = 0;
								LED8 = 1;
								LED7 = 1;
								LED6 = 1;
								LED5 = 1;
								LED4 = 1;
								bedLock = 0;
								backLock = 0;
								legLock = 0;
								pitchLock = 0;
								rollLock = 0;
								while(KEY_Scan(OUT));
								delay_ms(100);
								xEVENT = EV_MLOCK_ON;
								break;
				}
				if(cntTime > 400)
				{
					cntTime = 0;
                    LED9 = 0;
                    LED8 = 1;
                    LED7 = 1;
                    LED6 = 1;
                    LED5 = 1;
                    LED4 = 1;
					Run = 1;
					bedLock = 0;
					backLock = 0;
					legLock = 0;
					pitchLock = 0;
					rollLock = 0;
					xEVENT = EV_MLOCK_ON;
				}
				break;
	}
}

/**
  * @brief  Inside btn logic control
  * @param  None
  * @retval None
  */
void INBTN_Logic(void)
{
	static uint8_t xEVENT = EV_MLOCK_ON; //major lock Event variable
	static uint8_t backSTA = EV_BACKLOCK_OFF; //back lock Event variable
	static uint8_t legSTA = EV_LEGLOCK_OFF;//leg lock Event variable
	static uint16_t cntTime = 0; //Timing variable
	static uint8_t backLock = 0,legLock = 0; //back,leg sign bit 
	
	switch(xEVENT)
	{
		case EV_MLOCK_ON: //Default major lock is open 
				LED2 = 0;
				if(MLOCK_Scan(IN) == 0x1)   
				{
					xEVENT = EV_MLOCK_OFF;
					LED2 = 1;
					Run = 0;
					while(MLOCK_Scan(IN));
				}
				break;	
		case EV_MLOCK_OFF:
				cntTime++;
				switch(KEY_Scan(IN))
				{
					case 0x01:
							cntTime = 0;
							if(!backLock) 
							{
								RS485_RDTX_EN;
                                delay_ms(5);
                                /* 小护板腿和背左右有差别 */
								/* 从用户角度，左侧*/
								USART1_SendDateHex(INLEG_UP_ON);
																/* 从用户角度，右侧*/
                                //USART1_SendDateHex(INBACK_UP_ON);
								while(KEY_Scan(IN));
								USART1_SendDateHex(INLEG_UP_OFF);
                                delay_ms(5);
								RS485_RDRX_EN;
							}						
							break;
					case 0x02:
							cntTime = 0;						
							if(!legLock)
							{
								RS485_RDTX_EN;
                                delay_ms(5);
                                 /* 小护板腿和背左右有差别 */
								/* 从用户角度，左侧*/
								USART1_SendDateHex(INBACK_UP_ON);
								/* 从用户角度，右侧*/
								//USART1_SendDateHex(INLEG_UP_ON);
								while(KEY_Scan(IN));
								USART1_SendDateHex(INBACK_UP_OFF);
                                delay_ms(5);
								RS485_RDRX_EN;
							}
							break;
					case 0x03:
							cntTime = 0;
							RS485_RDTX_EN;
                            delay_ms(5);
							USART1_SendDateHex(IN_CALL_ON);
							while(KEY_Scan(IN));
							USART1_SendDateHex(IN_CALL_OFF);
                            delay_ms(5);
							RS485_RDRX_EN;
							break;
                    case 0x04:
                            cntTime = 0;
                            switch(backSTA)
                            {
                                case EV_BACKLOCK_OFF:
                                                    LED1 = 0;
                                                    backLock = 1;
                                                    backSTA = EV_BACKLOCK_ON;
                                                    break;
                                case EV_BACKLOCK_ON:
                                                    LED1= 1;
                                                    backLock = 0;
                                                    backSTA = EV_BACKLOCK_OFF;
                                                    break;
                            }
                            while(KEY_Scan(IN));
                            break;

                    case 0x05:
                        	cntTime = 0;
							switch(legSTA)
							{
								case EV_LEGLOCK_OFF:
													LED3 = 0;
													legLock = 1;
													legSTA = EV_LEGLOCK_ON;
													break;
								case EV_LEGLOCK_ON:
													LED3 = 1;
													legLock = 0;
													legSTA = EV_LEGLOCK_OFF;
													break;
							} 
							while(KEY_Scan(IN));
							break;
					case 0x06:
							cntTime = 0;
							if(!backLock) 
							{
								RS485_RDTX_EN;
                                delay_ms(5);
                                 /* 小护板腿和背左右有差别 */
								/* 从用户角度，左侧*/
								USART1_SendDateHex(INLEG_DOWN_ON);
								/* 从用户角度，右侧*/
								//USART1_SendDateHex(INBACK_DOWN_ON);
								while(KEY_Scan(IN));
								USART1_SendDateHex(INLEG_DOWN_OFF);
                                delay_ms(5);
								RS485_RDRX_EN;	
							}		
							break;
					case 0x07:
							cntTime = 0;
							if(!legLock) 
							{
								RS485_RDTX_EN;
                                delay_ms(5);
                                 /* 小护板腿和背左右有差别 */
								/* 从用户角度，左侧*/
								USART1_SendDateHex(INBACK_DOWN_ON);
								/* 从用户角度，右侧*/
								//USART1_SendDateHex(INLEG_DOWN_ON);
								while(KEY_Scan(IN));
								USART1_SendDateHex(INBACK_DOWN_OFF);
                                delay_ms(5);
								RS485_RDRX_EN;
							}
							break;
					case 0x08:
							cntTime = 0;
							LED1 = 1;
							LED2 = 0;
							LED3 = 1;
							backLock = 0;
							legLock = 0;
							while(KEY_Scan(IN));
							delay_ms(100);
							xEVENT = EV_MLOCK_ON;
							break;
				}
				if(cntTime > 400)
				{
					cntTime = 0;
					LED1 = 1;
					LED2 = 0;
					LED3 = 1;
					Run = 1;
					backLock = 0;
					legLock = 0;
					xEVENT = EV_MLOCK_ON;
				}
				break;
	}
}

/**
  * @brief  BTN major lock default led state 
  * @param  None
  * @retval None
  */
void BTN_Init(void)
{
	//Light up major lock led
	LED1 = 1;
	LED2 = 0;
    LED3 = 1;
    LED4 = 1;
    LED5 = 1;
    LED6 = 1;
    LED7 = 1;
	LED8 = 1;
    LED9 = 0;
}



