
#include "key.h"


/**
  * @brief 
  * @param  None
  * @retval 
  */
uint8_t KEY_Scan(BTNSelectState NewState)
{
	IWDG_Feed();
	if(NewState != OUT)
	{
		AllINScanEn;
		if(InsideSta == 0x1) return 0;
		delay_ms(5); 
		if(InsideSta == 0x1) return 0;

		H1ScanEn;
		switch(InLineValue & 0x07)
		{
			case 0x06:
					return 0x01; //Leg up
			case 0x05:
					return 0x02; //back up
			case 0x03:
					return 0x03; //call
		}
				
		H2ScanEn;
		switch(InLineValue & 0x07)
		{
			case 0x06:
					return 0x04; //Leg lock
			case 0x05:
					return 0x05; //back lock
		}
				
		H3ScanEn; 
		switch(InLineValue & 0x07)
		{
			case 0x06:
					return 0x06; //leg down
			case 0x05:
					return 0x07; //back down
			case 0x03:
					return 0x08; //main lock
		}
	}else
	{
		AllOUTScanEn;
		if(OutsideSta == 0x1) return 0;
		delay_ms(5); 
		if(OutsideSta == 0x1) return 0;


		H4ScanEn;
		switch(OutLineValue & 0xFF)
		{
			case 0xFD:
						return 0x09; //flower
			case 0xFB:
						return 0x10; //heart
			case 0xF7:
						return 0x11; //left roll
			case 0xEF:
						return 0x12; //head down leg up
			case 0xDf:
						return 0x13; //leg up
            case 0xBf:
                        return 0x14; //back up
            case 0x7f:
                        return 0x15; //bed up
		}
		
		H5ScanEn; 
		switch(OutLineValue & 0xFF)
		{
			case 0xF7:
						return 0x16; //roll lock
			case 0xEF:
						return 0x17; //head leg up/down lock
			case 0xDF:
						return 0x18; //leg lock
			case 0xBF:
						return 0x19; //back leg
			case 0x7f:
						return 0x20; //bed up/down lock
		}
		
		H6ScanEn;
		switch(OutLineValue & 0xFF)
		{
            case 0xFE:
						return 0x21; //Bedside lamp
			case 0xFD:
						return 0x22; //CPR
			case 0xFB:
						return 0x23; //main lock
			case 0xF7:
						return 0x24; //right roll
			case 0xEF:
						return 0x25; //head up leg down
			case 0xDf:
						return 0x26; //leg down
            case 0xBf:
                        return 0x27; //back down
            case 0x7f:
                        return 0x28; //bed down

		}		
	}
	return 0;
}

/**
  * @brief  
  * @param  None
  * @retval None
  */
uint8_t MLOCK_Scan(BTNSelectState NewState)
{
	if (NewState != OUT)
	{
		H3ScanEn; 
		if((InLineValue & 0x07) != 0x03) return 0;
		delay_ms(5);
		if((InLineValue & 0x07) != 0x03) return 0;

		return 0x1;
	}else
	{
		H6ScanEn; 
		if((OutLineValue & 0xFF) != 0xFB) return 0;
		delay_ms(5); 
		if((OutLineValue & 0xFF) != 0xFB) return 0;

		return 0x1;
	}
}


/**
  * @brief  
  * @param  None
  * @retval None
  */
void Key_Init(void)
{
  	GPIO_InitTypeDef GPIO_InitStructure;   
  	RCC_APB2PeriphClockCmd(H1_RCC|H2_RCC|H3_RCC|H4_RCC|H5_RCC|H6_RCC| \
						  	L1_RCC|L2_RCC|L3_RCC|L4_RCC|L5_RCC|L6_RCC|L7_RCC|L8_RCC|L9_RCC|L10_RCC|L11_RCC, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = H1_GPIO_PIN ;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	 
   	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   	GPIO_Init(H1_GPIO_PORT, &GPIO_InitStructure);
	GPIO_SetBits(H1_GPIO_PORT,H1_GPIO_PIN);
    
   	GPIO_InitStructure.GPIO_Pin = H2_GPIO_PIN ;
   	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	 
   	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   	GPIO_Init(H2_GPIO_PORT, &GPIO_InitStructure);
	GPIO_SetBits(H2_GPIO_PORT,H2_GPIO_PIN);
    
   	GPIO_InitStructure.GPIO_Pin = H3_GPIO_PIN ;
   	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	 
   	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   	GPIO_Init(H3_GPIO_PORT, &GPIO_InitStructure);
	GPIO_SetBits(H3_GPIO_PORT,H3_GPIO_PIN);
	
   	GPIO_InitStructure.GPIO_Pin = H4_GPIO_PIN ;	
   	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	 
   	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;   
   	GPIO_Init(H4_GPIO_PORT, &GPIO_InitStructure);
	GPIO_SetBits(H4_GPIO_PORT,H4_GPIO_PIN);
	 
	GPIO_InitStructure.GPIO_Pin = H5_GPIO_PIN ;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	 
   	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   	GPIO_Init(H5_GPIO_PORT, &GPIO_InitStructure);
	GPIO_SetBits(H5_GPIO_PORT,H5_GPIO_PIN);
	
	GPIO_InitStructure.GPIO_Pin = H6_GPIO_PIN ;  
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	 
   	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   	GPIO_Init(H6_GPIO_PORT, &GPIO_InitStructure);
	GPIO_SetBits(H6_GPIO_PORT,H6_GPIO_PIN);

    
	GPIO_InitStructure.GPIO_Pin = L1_GPIO_PIN ;   
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	 
	GPIO_Init(L1_GPIO_PORT, &GPIO_InitStructure);	
   
	GPIO_InitStructure.GPIO_Pin = L2_GPIO_PIN ;   
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	 
	GPIO_Init(L2_GPIO_PORT, &GPIO_InitStructure);	
   
	GPIO_InitStructure.GPIO_Pin = L3_GPIO_PIN ;   
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	
	GPIO_Init(L3_GPIO_PORT, &GPIO_InitStructure);	
	
	GPIO_InitStructure.GPIO_Pin = L4_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	   
	GPIO_Init(L4_GPIO_PORT, &GPIO_InitStructure);	
	 
	GPIO_InitStructure.GPIO_Pin = L5_GPIO_PIN ;   
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	 
	GPIO_Init(L5_GPIO_PORT, &GPIO_InitStructure);	
   
	GPIO_InitStructure.GPIO_Pin = L6_GPIO_PIN ;   
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	 
	GPIO_Init(L6_GPIO_PORT, &GPIO_InitStructure);	
   
	GPIO_InitStructure.GPIO_Pin = L7_GPIO_PIN ;   
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	 
	GPIO_Init(L7_GPIO_PORT, &GPIO_InitStructure);	
	
	GPIO_InitStructure.GPIO_Pin = L8_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	   
	GPIO_Init(L8_GPIO_PORT, &GPIO_InitStructure);	

    GPIO_InitStructure.GPIO_Pin = L9_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	   
	GPIO_Init(L9_GPIO_PORT, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = L10_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	   
	GPIO_Init(L10_GPIO_PORT, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = L11_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	   
	GPIO_Init(L11_GPIO_PORT, &GPIO_InitStructure);
}





