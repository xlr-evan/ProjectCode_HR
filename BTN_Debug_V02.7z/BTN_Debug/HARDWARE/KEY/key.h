#ifndef __KEY_H
#define __KEY_H	 

#include "stm32f10x.h"
#include "sys.h"
#include "usart.h"
#include "delay.h"
#include "led.h"
#include "app.h"


/* �����ʱ�Ӷ��� */
#define H1_RCC RCC_APB2Periph_GPIOB
#define H2_RCC RCC_APB2Periph_GPIOD
#define H3_RCC RCC_APB2Periph_GPIOD
#define H4_RCC RCC_APB2Periph_GPIOE
#define H5_RCC RCC_APB2Periph_GPIOE
#define H6_RCC RCC_APB2Periph_GPIOE

/* �����ʱ�Ӷ��� */
#define L1_RCC RCC_APB2Periph_GPIOD
#define L2_RCC RCC_APB2Periph_GPIOD
#define L3_RCC RCC_APB2Periph_GPIOD
#define L4_RCC RCC_APB2Periph_GPIOA
#define L5_RCC RCC_APB2Periph_GPIOA
#define L6_RCC RCC_APB2Periph_GPIOA
#define L7_RCC RCC_APB2Periph_GPIOA
#define L8_RCC RCC_APB2Periph_GPIOC
#define L9_RCC RCC_APB2Periph_GPIOC
#define L10_RCC RCC_APB2Periph_GPIOE
#define L11_RCC RCC_APB2Periph_GPIOE


/* ������˿ڡ����Ŷ��� */
#define H1_GPIO_PORT 	GPIOB           
#define H2_GPIO_PORT 	GPIOD   
#define H3_GPIO_PORT 	GPIOD         
#define H4_GPIO_PORT 	GPIOE 
#define H5_GPIO_PORT 	GPIOE 
#define H6_GPIO_PORT 	GPIOE 

#define H1_GPIO_PIN 	GPIO_Pin_15
#define H2_GPIO_PIN 	GPIO_Pin_10
#define H3_GPIO_PIN 	GPIO_Pin_12
#define H4_GPIO_PIN 	GPIO_Pin_12
#define H5_GPIO_PIN 	GPIO_Pin_13
#define H6_GPIO_PIN 	GPIO_Pin_14

/* ������˿ڡ����Ŷ��� */
#define L1_GPIO_PORT 	GPIOD           
#define L2_GPIO_PORT 	GPIOD   
#define L3_GPIO_PORT 	GPIOD           
#define L4_GPIO_PORT 	GPIOA 
#define L5_GPIO_PORT 	GPIOA
#define L6_GPIO_PORT 	GPIOA
#define L7_GPIO_PORT 	GPIOA
#define L8_GPIO_PORT 	GPIOC
#define L9_GPIO_PORT 	GPIOC
#define L10_GPIO_PORT 	GPIOE
#define L11_GPIO_PORT 	GPIOE

#define L1_GPIO_PIN 	GPIO_Pin_9
#define	L2_GPIO_PIN 	GPIO_Pin_11
#define L3_GPIO_PIN 	GPIO_Pin_8
#define L4_GPIO_PIN 	GPIO_Pin_4
#define L5_GPIO_PIN 	GPIO_Pin_5
#define L6_GPIO_PIN		GPIO_Pin_6
#define L7_GPIO_PIN 	GPIO_Pin_7
#define L8_GPIO_PIN 	GPIO_Pin_4
#define L9_GPIO_PIN 	GPIO_Pin_5
#define L10_GPIO_PIN 	GPIO_Pin_10
#define L11_GPIO_PIN 	GPIO_Pin_11




#define	OutsideSta	(GPIO_ReadInputDataBit(L4_GPIO_PORT,L4_GPIO_PIN) & \
					 GPIO_ReadInputDataBit(L5_GPIO_PORT,L5_GPIO_PIN) & \
					 GPIO_ReadInputDataBit(L6_GPIO_PORT,L6_GPIO_PIN) & \
					 GPIO_ReadInputDataBit(L7_GPIO_PORT,L7_GPIO_PIN) & \
                     GPIO_ReadInputDataBit(L8_GPIO_PORT,L8_GPIO_PIN) & \
                     GPIO_ReadInputDataBit(L9_GPIO_PORT,L9_GPIO_PIN) & \
                     GPIO_ReadInputDataBit(L10_GPIO_PORT,L10_GPIO_PIN) & \
					 GPIO_ReadInputDataBit(L11_GPIO_PORT,L11_GPIO_PIN))
					 
#define	InsideSta	(GPIO_ReadInputDataBit(L1_GPIO_PORT,L1_GPIO_PIN) & \
					 GPIO_ReadInputDataBit(L2_GPIO_PORT,L2_GPIO_PIN) & \
					 GPIO_ReadInputDataBit(L3_GPIO_PORT,L3_GPIO_PIN))


#define	InLineValue	(GPIO_ReadInputDataBit(L1_GPIO_PORT,L1_GPIO_PIN) | \
					(GPIO_ReadInputDataBit(L2_GPIO_PORT,L2_GPIO_PIN) << 1) | \
					(GPIO_ReadInputDataBit(L3_GPIO_PORT,L3_GPIO_PIN) << 2))

#define	OutLineValue	(GPIO_ReadInputDataBit(L4_GPIO_PORT,L4_GPIO_PIN) | \
						(GPIO_ReadInputDataBit(L5_GPIO_PORT,L5_GPIO_PIN) << 1) | \
						(GPIO_ReadInputDataBit(L6_GPIO_PORT,L6_GPIO_PIN) << 2) | \
						(GPIO_ReadInputDataBit(L7_GPIO_PORT,L7_GPIO_PIN) << 3) | \
						(GPIO_ReadInputDataBit(L8_GPIO_PORT,L8_GPIO_PIN) << 4) | \
						(GPIO_ReadInputDataBit(L9_GPIO_PORT,L9_GPIO_PIN) << 5) | \
						(GPIO_ReadInputDataBit(L10_GPIO_PORT,L10_GPIO_PIN) << 6) | \
						(GPIO_ReadInputDataBit(L11_GPIO_PORT,L11_GPIO_PIN) << 7))	
						
#define	AllINScanEn		GPIO_ResetBits(H1_GPIO_PORT,H1_GPIO_PIN); \
						GPIO_ResetBits(H2_GPIO_PORT,H2_GPIO_PIN); \
						GPIO_ResetBits(H3_GPIO_PORT,H3_GPIO_PIN)

#define	AllINScanDis	GPIO_SetBits(H1_GPIO_PORT,H1_GPIO_PIN); \
						GPIO_SetBits(H2_GPIO_PORT,H2_GPIO_PIN); \
						GPIO_SetBits(H3_GPIO_PORT,H3_GPIO_PIN)

#define	AllOUTScanEn	GPIO_ResetBits(H4_GPIO_PORT,H4_GPIO_PIN); \
						GPIO_ResetBits(H5_GPIO_PORT,H5_GPIO_PIN); \
						GPIO_ResetBits(H6_GPIO_PORT,H6_GPIO_PIN); 

#define	AllOUTScanDis	GPIO_ResetBits(H4_GPIO_PORT,H4_GPIO_PIN); \
						GPIO_ResetBits(H5_GPIO_PORT,H5_GPIO_PIN); \
						GPIO_ResetBits(H6_GPIO_PORT,H6_GPIO_PIN); 
													
#define	H1ScanEn		GPIO_ResetBits(H1_GPIO_PORT,H1_GPIO_PIN); \
						GPIO_SetBits(H2_GPIO_PORT,H2_GPIO_PIN); \
						GPIO_SetBits(H3_GPIO_PORT,H3_GPIO_PIN)

											
#define	H2ScanEn		GPIO_SetBits(H1_GPIO_PORT,H1_GPIO_PIN); \
						GPIO_ResetBits(H2_GPIO_PORT,H2_GPIO_PIN); \
						GPIO_SetBits(H3_GPIO_PORT,H3_GPIO_PIN)


#define	H3ScanEn		GPIO_SetBits(H1_GPIO_PORT,H1_GPIO_PIN); \
						GPIO_SetBits(H2_GPIO_PORT,H2_GPIO_PIN); \
						GPIO_ResetBits(H3_GPIO_PORT,H3_GPIO_PIN)

#define	H4ScanEn		GPIO_ResetBits(H4_GPIO_PORT,H4_GPIO_PIN); \
						GPIO_SetBits(H5_GPIO_PORT,H5_GPIO_PIN); \
						GPIO_SetBits(H6_GPIO_PORT,H6_GPIO_PIN); 

#define	H5ScanEn		GPIO_SetBits(H4_GPIO_PORT,H4_GPIO_PIN); \
						GPIO_ResetBits(H5_GPIO_PORT,H5_GPIO_PIN); \
						GPIO_SetBits(H6_GPIO_PORT,H6_GPIO_PIN); \

#define	H6ScanEn		GPIO_SetBits(H4_GPIO_PORT,H4_GPIO_PIN); \
						GPIO_SetBits(H5_GPIO_PORT,H5_GPIO_PIN); \
						GPIO_ResetBits(H6_GPIO_PORT,H6_GPIO_PIN); 	



typedef enum {OUT = 0, IN = !OUT} BTNSelectState;


void Key_Init(void);
uint8_t KEY_Scan(BTNSelectState NewState);
void KEY_Test(void);
uint8_t MLOCK_Scan(BTNSelectState NewState);


#endif




