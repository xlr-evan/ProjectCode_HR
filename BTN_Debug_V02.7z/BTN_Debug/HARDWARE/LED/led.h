#ifndef __LED_H
#define __LED_H	 

#include "stm32f10x.h"
#include "usart.h"
#include "sys.h"


/* LED����˿ڡ����Ŷ��� */
#define	Run			PCout(9)
#define	LED1		PBout(12)
#define	LED2		PBout(13)
#define	LED3		PBout(14)
#define	LED4		PBout(0)
#define	LED5		PBout(1)
#define	LED6		PBout(2)
#define	LED7		PEout(7)
#define	LED8		PEout(8)
#define	LED9		PEout(9)


typedef enum {OFF = 1, ON = 0} LEDState;

void LED_Init(void);


#endif



