
#include "led.h"
#include "key.h"
#include "delay.h"
#include "time.h"
#include "usart.h"
#include "app.h"


int main(void)
{
	SYS_Init();
	BTN_Poll();	

	return 0;
}
















